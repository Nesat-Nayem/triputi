/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'ko', {
	label: '스타일',
	panelTitle: '전체 구성 스타일',
	panelTitle1: '블록 스타일',
	panelTitle2: '인라인 스타일',
	panelTitle3: '객체 스타일'
} );
