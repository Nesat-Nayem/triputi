/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'en-ca', {
	label: 'Styles',
	panelTitle: 'Formatting Styles', // MISSING
	panelTitle1: 'Block Styles',
	panelTitle2: 'Inline Styles',
	panelTitle3: 'Object Styles'
} );
